#ifndef QUIZMODEL_H
#define QUIZMODEL_H

#include <QAbstractListModel>
#include <QJsonArray>
#include<QtCore>

class QuizModel : public QAbstractListModel
{
    Q_OBJECT

public:
    enum Roles {
            QuestionRole = Qt::UserRole + 1,
            OptionsRole,
            AnswerRole
        };
    struct QuizItem {
            QString question;
            QStringList options;
            QString answer;
        };
    explicit QuizModel(QObject *parent = nullptr);

    // Header:
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

    bool setHeaderData(int section, Qt::Orientation orientation, const QVariant &value, int role = Qt::EditRole) override;

    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;

    // Fetch data dynamically:
    bool hasChildren(const QModelIndex &parent = QModelIndex()) const override;

    bool canFetchMore(const QModelIndex &parent) const override;
    void fetchMore(const QModelIndex &parent) override;

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

    // Editable:
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    // Add data:
    bool insertRows(int row, int count, const QModelIndex &parent = QModelIndex()) override;

    // Remove data:
    bool removeRows(int row, int count, const QModelIndex &parent = QModelIndex()) override;

    void loadFromFile(const QString &filePath);

    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE QVariantMap get(int index) const;



private:


        QList<QuizItem> m_items;
};

#endif // QUIZMODEL_H
