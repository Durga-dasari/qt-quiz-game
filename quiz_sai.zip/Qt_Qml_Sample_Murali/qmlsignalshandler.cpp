#include "qmlsignalshandler.h"

Qmlsignalshandler *Qmlsignalshandler::m_qml_qt = nullptr;

Qmlsignalshandler::Qmlsignalshandler(QObject *parent) : QObject(parent)
{
    m_model = new Datamodels();
    m_tempmodel = new  QuizModel();
}

Qmlsignalshandler *Qmlsignalshandler::getInstance()
{
    if(m_qml_qt == nullptr){
        m_qml_qt = new Qmlsignalshandler ();
    }
    return m_qml_qt;
}


Datamodels *Qmlsignalshandler::model() const
{
    return m_model;
}

QuizModel *Qmlsignalshandler::m_quizmodel() const
{
    return m_tempmodel;
}


void Qmlsignalshandler::add_DatatoModel()
{
//    m_tempmodel->loadFromFile("/home/magapulakshmanasai/Qt_Qml_Sample_Murali/Quiz.json");
}
