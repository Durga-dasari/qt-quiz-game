#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    view = new QQuickView();
    view->setSource(QUrl("qrc:/Testsss.qml"));
    QWidget *widget = nullptr ;
    widget = QWidget::createWindowContainer(view);
    widget->setFocusPolicy(Qt::TabFocus);
    ui->verticalWidget->layout()->addWidget(widget);
}

MainWindow::~MainWindow()
{
    delete ui;
}

