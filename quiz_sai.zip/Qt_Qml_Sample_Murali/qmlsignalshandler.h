#ifndef QMLSIGNALSHANDLER_H
#define QMLSIGNALSHANDLER_H

#include <QObject>
#include <QtCore>
#include <datamodels.h>
#include<quizmodel.h>
class Qmlsignalshandler : public QObject
{
    Q_OBJECT
    Datamodels *m_model;
    QuizModel *m_tempmodel;

public:
    Q_PROPERTY(Datamodels *model READ model CONSTANT)
    Q_PROPERTY(QuizModel *m_quizmodel READ m_quizmodel CONSTANT)

    explicit Qmlsignalshandler(QObject *parent = nullptr);

    static Qmlsignalshandler *getInstance();

    static Qmlsignalshandler *m_qml_qt;


    Datamodels *model() const;
    QuizModel *m_quizmodel() const;

    Datamodels::bikeModelData data;
    QuizModel::QuizItem itemdata;

public slots:
    Q_INVOKABLE void add_DatatoModel();

signals:

};

#endif // QMLSIGNALSHANDLER_H
