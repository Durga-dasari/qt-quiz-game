#include "datamodels.h"

Datamodels::Datamodels(QObject *parent)
    : QAbstractListModel(parent)
{
}

QVariant Datamodels::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

bool Datamodels::setHeaderData(int section, Qt::Orientation orientation, const QVariant &value, int role)
{
    if (value != headerData(section, orientation, role)) {
        // FIXME: Implement me!
        emit headerDataChanged(orientation, section, section);
        return true;
    }
    return false;
}

int Datamodels::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid())
        return 0;

    return datamodel.count();

    // FIXME: Implement me!
}

bool Datamodels::hasChildren(const QModelIndex &parent) const
{
    // FIXME: Implement me!
}

bool Datamodels::canFetchMore(const QModelIndex &parent) const
{
    // FIXME: Implement me!
    return false;
}

void Datamodels::fetchMore(const QModelIndex &parent)
{
    // FIXME: Implement me!
}

QVariant Datamodels::data(const QModelIndex &index, int role) const
{
    //    if (!index.isValid())
    //        return QVariant();

    qDebug()<<"getting data for row"<<index.row()<<"Role"<<role;
    bikeModelData item = datamodel.at(index.row());

    switch (role) {
    case BikeName:
        return item.bikeName;
    case BikeOwner:
        return item.bikeOwner;
    case StateName:
        return item.stateName;
    case Licence:
        return item.licence;
    default:
        return QVariant();
    }
    // FIXME: Implement me!
}

bool Datamodels::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (data(index, role) != value) {
        // FIXME: Implement me!
        emit dataChanged(index, index, QVector<int>() << role);
        return true;
    }
    return false;
}

Qt::ItemFlags Datamodels::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return Qt::NoItemFlags;

    return Qt::ItemIsEditable; // FIXME: Implement me!
}

bool Datamodels::insertRows(int row, int count, const QModelIndex &parent)
{
    beginInsertRows(parent, row, row + count - 1);
    // FIXME: Implement me!
    endInsertRows();
}

bool Datamodels::removeRows(int row, int count, const QModelIndex &parent)
{
    beginRemoveRows(parent, row, row + count - 1);
    // FIXME: Implement me!
    endRemoveRows();
}

QHash<int, QByteArray> Datamodels::roleNames() const
{
    QHash<int, QByteArray> names;
    names[BikeName] = "bikename";
    names[BikeOwner] = "bikeowner";
    names[StateName] = "statename";
    names[Licence] = "license";

    return names;
}

void Datamodels::additem(bikeModelData data)
{

    qDebug()<<"values are inserted"<<data.bikeName;
    beginInsertRows(QModelIndex(), rowCount(), rowCount()-1);
    datamodel.append(data);
    endInsertRows();
    emit layoutChanged();
}
