#include "quizmodel.h"

QuizModel::QuizModel(QObject *parent)
    : QAbstractListModel(parent)
{
loadFromFile("/home/magapulakshmanasai/Qt_Qml_Sample_Murali/Quiz.json");
}

QVariant QuizModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

bool QuizModel::setHeaderData(int section, Qt::Orientation orientation, const QVariant &value, int role)
{
    if (value != headerData(section, orientation, role)) {
        // FIXME: Implement me!
        emit headerDataChanged(orientation, section, section);
        return true;
    }
    return false;
}

int QuizModel::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid())
        return 0;

    return m_items.count();

    // FIXME: Implement me!
}

bool QuizModel::hasChildren(const QModelIndex &parent) const
{
    // FIXME: Implement me!
}

bool QuizModel::canFetchMore(const QModelIndex &parent) const
{
    // FIXME: Implement me!
    return false;
}

void QuizModel::fetchMore(const QModelIndex &parent)
{
    // FIXME: Implement me!
}

QVariant QuizModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_items.size())
            return {};

        const auto &item = m_items[index.row()];
        switch (role) {
            case QuestionRole: return item.question;
            case OptionsRole: return QVariant::fromValue(item.options);
            case AnswerRole: return item.answer;
        }

        return {};
}

bool QuizModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (data(index, role) != value) {
        // FIXME: Implement me!
        emit dataChanged(index, index, QVector<int>() << role);
        return true;
    }
    return false;
}

QHash<int, QByteArray> QuizModel::roleNames() const {
    return {
        {QuestionRole, "question"},
        {OptionsRole, "options"},
        {AnswerRole, "answer"}
    };
}
Qt::ItemFlags QuizModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return Qt::NoItemFlags;

    return Qt::ItemIsEditable; // FIXME: Implement me!
}

bool QuizModel::insertRows(int row, int count, const QModelIndex &parent)
{
    beginInsertRows(parent, row, row + count - 1);
    // FIXME: Implement me!
    endInsertRows();
}

bool QuizModel::removeRows(int row, int count, const QModelIndex &parent)
{
    beginRemoveRows(parent, row, row + count - 1);
    // FIXME: Implement me!
    endRemoveRows();
}
void QuizModel::loadFromFile(const QString &filePath) {
    qDebug()<<"loadFromFile"<<filePath;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) return;

    QByteArray jsonData = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    qDebug()<<"doc"<<doc;
    if (!doc.isObject()) return;

    QJsonArray quizArray = doc.object().value("quiz").toArray();
    for (const QJsonValue &val : quizArray) {
        QJsonObject obj = val.toObject();
        QuizItem item;
        item.question = obj["question"].toString();
        for (const QJsonValue &opt : obj["options"].toArray()) {
            item.options.append(opt.toString());
        }
        item.answer = obj["answer"].toString();
        m_items.append(item);
    }

    beginResetModel();
    endResetModel();
}

QVariantMap QuizModel::get(int index) const {
    QVariantMap map;
    if (index < 0 || index >= m_items.size())
        return map;

    const auto &item = m_items[index];
    map["question"] = item.question;
    map["options"] = QVariant::fromValue(item.options);
    map["answer"] = item.answer;
    return map;
}

